%二分法计算函数的零点
%输入求根区间a，b和求根精度abtol
%函数输出根的近似值，和迭代次数
function dichotomy()
a=input('请输入求根的下限，a=');
b=input('请输入求根的上限，b=');
abtol=input('请输入求根的精度，abtol=');
iterations=0;
ya=fun(a);yb=fun(b);%程序中调用的fun.m为函数
if ya*yb>0
    fprintf('注意：ya*yb>0,请重新调整区间端点a和b.'),return
else
    [iter,y]=dichotomyRoot(a,b,abtol,iterations);
    disp('Root='),disp(y);
end
disp('迭代次数='),disp(iter);
end
