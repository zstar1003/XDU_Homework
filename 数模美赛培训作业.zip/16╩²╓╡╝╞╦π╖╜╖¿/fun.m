function y1=fun(x)
y1=exp(x)+10*x-2;
