%求解模糊矩阵R的k次方(模糊矩阵的合成）
function y=FuzzyR2(R,rows)
    y=zeros(rows,rows);
    for i = 1:rows
        for j = 1:rows
            min_tmp=zeros(1,rows);
            for k=1:rows
                min_tmp(k)=min(R(i,k),R(k,j));
            end
            y(i,j)=max(min_tmp);
        end
    end
end
