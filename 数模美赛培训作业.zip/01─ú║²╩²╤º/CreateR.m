function y=CreateR(inputdata,rows,columns,c)
    y=zeros(rows,rows);
    for i=1:rows
        for j=1:rows
            y(i,j)=1-distance(inputdata(i,:),inputdata(j,:),columns,c);
        end
    end
end

            