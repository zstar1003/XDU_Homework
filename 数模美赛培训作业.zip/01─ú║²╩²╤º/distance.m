function y=distance(x1,x2,length,c)
    y=0;
    for i=1:length
        y=y+c*abs(x1(i)-x2(i));
    end
end
