input_data=xlsread("fuzzy_theory_data.xlsx",1,"B1:E5")
rows=5;
columns=4;
c=0.1;
R=CreateR(input_data,rows,columns,c)   %
Rk=GetRk(R,rows)

                                                         
