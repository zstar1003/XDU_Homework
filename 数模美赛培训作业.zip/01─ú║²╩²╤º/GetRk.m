%传递闭包法求模糊等价矩阵
function y=GetRk(R,rows)
    k=1;
    while(1)
        if(R==FuzzyR2(R,rows))
            break
        end
        R=FuzzyR2(R,rows);
        k=k*2;
    end
    y=R;
end

    