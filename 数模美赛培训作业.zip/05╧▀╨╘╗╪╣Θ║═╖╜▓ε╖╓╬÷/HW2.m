clear all;
clc;
a=3;
%% 输入数据
x1=[40,48,38,42,45,46]';
n1=length(x1);
x2=[26,34,30,28,32,33]';
n2=length(x2);
x3=[39,40,48,50,50,52]';
n3=length(x3);
n=n1+n2+n3;
%% 计算均值
y1=mean(x1);
y2=mean(x2);
y3=mean(x3);
my=(sum(x1)+sum(x2)+sum(x3))/n;
y11=x1-y1*ones(n1,1);
y12=x2-y2*ones(n2,1);
y13=x3-y3*ones(n3,1);
%%因素平方和 误差平方和
SSE=y11'*y11+y12'*y12+y13'*y13,
SSA=(y1-my)^2*n1+(y2-my)^2*n2+(y3-my)^2*n3,
SST=SSE+SSA,
MSA=SSA/(a-1),
MSE=SSE/(n-a),
F=MSA/MSE
%% 区间估计
t_alpha=2.262;
u1_left=y1-y2-sqrt(MSE)*sqrt(1/n1+1/n2)*t_alpha,
u1_right=y1-y2+sqrt(MSE)*sqrt(1/n1+1/n2)*t_alpha,

u2_left=y1-y3-sqrt(MSE)*sqrt(1/n1+1/n3)*t_alpha,
u2_right=y1-y3+sqrt(MSE)*sqrt(1/n1+1/n3)*t_alpha,

u3_left=y2-y3-sqrt(MSE)*sqrt(1/n3+1/n2)*t_alpha,
u3_right=y2-y3+sqrt(MSE)*sqrt(1/n3+1/n2)*t_alpha,