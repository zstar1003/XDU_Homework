clear all
d=1;%两条边的距离
l=0.6;%针的长度
    %总的实验次数
n = input('请输入n:');
N=n;
m=0;
mpi=0;
x=Mixrand(3*N);
for i=1:n
x1(i)=x(i);
y1(i)=x(i+N);
Mixpi(i)= pi*x(i+2*N);%mpi为接收到的(0-2pi/)的随机数 
if x1(i)<l*sin(Mixpi(i))/2
  m=m+1;
end
end
rectangle('Position',[-0.6 -0.6 2.2 2.2],'EdgeColor','r','LineWidth',3);%画矩形
hold on;
rectangle('Position',[0 0 1 1],'EdgeColor','m','LineWidth',7);
axis([-0.7 1.7 -0.7 1.7]);
for i=1:n
   P(i)=cos(2*Mixpi(i));
   Q(i)=sin(2*Mixpi(i));
   x11(i)=x1(i)+l*P(i);
   y11(i)=y1(i)+l*Q(i);
hold on;
end
plot(x1,y1,'X');
title('模拟蒲丰投针');
xlabel('X轴');
ylabel('Y轴');
X=[x1;x11];
Y=[y1;y11];
line(X,Y);
q=l*n/(d*m)
