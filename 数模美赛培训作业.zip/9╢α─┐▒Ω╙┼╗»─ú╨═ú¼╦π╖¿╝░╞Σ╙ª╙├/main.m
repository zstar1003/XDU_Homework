clear 
clc 
fitnessfcn=@Fun;
 nvars=3; 
 lb=[0,0,0]; 
 ub=[100,100,250/3]; 
 A=[1,1,1;0.48,0.663,0.504];b=[80;160]; 
 Aeq=[];beq=[]; 
 
options=gaoptimset('paretoFraction',0.3,'populationsize',200,'generations',300,'stallGenLimit',200,'TolFun',1e-10); 

[x,fval]=gamultiobj(fitnessfcn,nvars,A,b,Aeq,beq,lb,ub,options)

plot(fval(:,1),fval(:,2),'pr')
xlabel('f_1(x)')
ylabel('f_2(x)')
title('Pareto front')
grid on