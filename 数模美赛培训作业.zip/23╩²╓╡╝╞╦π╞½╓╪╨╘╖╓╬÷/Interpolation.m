x = 0:2*pi;    
y = sin(x);    
xx = 0:0.5:2*pi;    
  
% interp1对sin函数进行分段线性插值，调用interp1的时候，默认的是分段线性插值    
y1 = interp1(x,y,xx,'linear');    
subplot(2,2,1);  
plot(x,y,'o',xx,y1,'r')    
title('分段线性插值')    
    
% 临近插值    
y2 = interp1(x,y,xx,'nearest');    
subplot(2,2,2);  
plot(x,y,'o',xx,y2,'r');    
title('临近插值')    
    
%球面线性插值    
y3 = interp1(x,y,xx,'spline');    
subplot(2,2,3);  
plot(x,y,'o',xx,y3,'r')    
title('球面插值')    
    
%三次多项式插值法    
y4 = interp1(x,y,xx,'pchip');    
subplot(2,2,4);  
plot(x,y,'o',xx,y4,'r');    
title('三次多项式插值')    