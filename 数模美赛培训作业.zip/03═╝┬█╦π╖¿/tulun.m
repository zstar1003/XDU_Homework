weight=    [0     16     22     30   41   59  ;
            Inf    0     16     22   30   41   ;
           Inf     Inf     0    17    23    31  ;
           Inf    Inf    Inf      0   17    23  ;
          Inf     Inf    Inf    Inf     0     18   ;
          Inf   Inf     Inf   Inf     Inf      0   ;];
[dis, path]=dijkstra(weight,1, 6)